Unfortunately, we are unable to accept external contributions at this time.
However, if you need to reach the developers, you may do so at
lt-speech-engine-maintainers@google.com.
